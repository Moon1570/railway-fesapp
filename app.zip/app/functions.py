#Body surface area (BSA) calculator
def calcBSA(weight):
    return (((weight * 4)+7)/(90+weight))*100